<div class="panel box box-warning">
    <div class="box-header with-border">
        <h4 class="box-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                Carta de terminación laboral
            </a>
        </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
        <div class="form-group">
            <label for="reason3">Rason</label>
            <input type="text" name="reason3" id="reason3" class="form-control" value="TERMINACION DE CONTRATO LABORAL CON JUSTA CAUSA">
        </div>
        <div class="form-group">
            <label for="letter3">Detalles</label>
            <textarea name="letter3" id="letter3" cols="6" rows="6" class="form-control"></textarea>
        </div>
    </div>
</div>