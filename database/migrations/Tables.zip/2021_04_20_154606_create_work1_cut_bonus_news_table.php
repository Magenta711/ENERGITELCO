<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWork1CutBonusNewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work1_cut_bonus_news', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('approver_id');
            $table->double('total',10.2)->nullable();
            $table->date('start_date');
            $table->date('end_date')->nullable();
            $table->integer('formats');
            $table->boolean('has_bonus');
            $table->boolean('has_box');
            $table->double('value_box',10.2);
            $table->double('value_bonu',10.2);
            $table->boolean('status');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work1_cut_bonus_news');
    }
}
