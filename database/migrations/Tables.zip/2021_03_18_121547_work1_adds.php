<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Work1Adds extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('work1_adds', function (Blueprint $table) {
            $table->integer('pending_u1');
            $table->integer('pending_u2');
            $table->integer('pending_u3');
            $table->integer('pending_u4');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('work1_adds', function (Blueprint $table) {
            //
        });
    }
}
