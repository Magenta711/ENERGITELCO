<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddWork1Add extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('work1_adds', function (Blueprint $table) {
            $table->integer('f9a1u4')->nullable();
            $table->integer('f9a2u4')->nullable();
            $table->integer('f9a3u4')->nullable();
            $table->string('f2b1u4',20)->nullable();
            $table->string('f2b2u4',20)->nullable();
            $table->string('f2b3u4',20)->nullable();
            $table->string('f2b4u4',20)->nullable();
            $table->string('f2b5u4',20)->nullable();
            $table->string('f2b6u4',20)->nullable();
            $table->string('f2c1u4',20)->nullable();
            $table->string('f2c2u4',20)->nullable();
            $table->string('f2c4u4',20)->nullable();
            $table->string('f2c3u4',20)->nullable();
            $table->string('f6a1u4',20)->nullable();
            $table->string('f6a2u4',20)->nullable();
            $table->string('f6a3u4',20)->nullable();
            $table->string('f6a4u4',20)->nullable();
            $table->string('f6a5u4',20)->nullable();
            $table->string('foto_moto4',100)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('work1_adds', function (Blueprint $table) {
            //
        });
    }
}
