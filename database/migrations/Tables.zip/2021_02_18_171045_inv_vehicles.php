<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class InvVehicles extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inv_vehicles', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('brand');
            $table->string('plate');
            $table->string('line');
            $table->string('color');
            $table->string('model');
            $table->string('start_date');
            $table->string('exp_date');
            $table->string('avatar');
            $table->string('type');
            $table->string('body_type');
            $table->string('soat');
            $table->string('soat_date');
            $table->string('enrollment');
            $table->string('enrollment_date');
            $table->string('fuel');
            $table->string('capacity');
            $table->string('gases');
            $table->string('gases_date');
            $table->string('technomechanical');
            $table->string('technomechanical_date');
            $table->string('toll_ship');
            $table->string('tires');
            $table->string('spare_tire');
            $table->string('first_aid_kit');
            $table->string('first_aid_kit_date');
            $table->string('cc');
            $table->boolean('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inv_vehicles');
    }
}
