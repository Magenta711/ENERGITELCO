<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProceedingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('proceedings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('affair');
            $table->date('date');
            $table->string('city');
            $table->string('type');
            $table->time('time_start');
            $table->time('time_end');
            $table->string('place');
            $table->text('theme');
            $table->text('development');
            $table->unsignedBigInteger('responsable_id');
            $table->boolean('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('proceedings');
    }
}
