<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Work1CutBonuses extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('work1_cut_bonuses', function (Blueprint $table) {
            $table->boolean('has_bonus');
            $table->boolean('has_box');
            $table->integer('value_box');
            $table->integer('value_bonu');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('work1_cut_bonuses', function (Blueprint $table) {
            //
        });
    }
}
