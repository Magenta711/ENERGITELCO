<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Work9 extends Model
{
    protected $table = "work9";
    // protected $fillable = ['responsable_id','employee_id','coordinator_id','reason','description','value','estado'];
    // protected $guarder = ['id'];
}
